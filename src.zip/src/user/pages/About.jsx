import "./about.css"

import { Link } from "react-router-dom";
import data from "../components/data";
import Header from "../components/header.jsx";
import Footer from "../components/footer.jsx";
import Show from "../components/show.jsx";


function About() {
    return (
        <>
            <Header />
            <div className="card_cont_back">
                <div className="card_back">
                <p className="cardtext">Check each product page for other buying options. Price and other details may vary based on product size and colour.
                </p>
                
                    
                    {data.map((item) => (



                        
                            <div className="box">
                                <img src={item.img} alt="" />
                                <div className="text">
                                    <h2>Premium Product</h2>
                                    
                                    <div className="pricee">
                                        <h1><sup>₹</sup>{item.price}</h1>
                                    </div>
                                    <p>Save money with our offer</p>
                                    <span>Fresh food</span>
                                    <p>Free Delivery On <b>Sunday</b></p>
                                    <Link to="/detail"> <button className="btn_3">More Info</button></Link>
                                </div>
                            </div>

                        
                    ))}
                
                </div>
            </div>
            <Show/>
            <Footer />

        </>
    )
}
export default About;

