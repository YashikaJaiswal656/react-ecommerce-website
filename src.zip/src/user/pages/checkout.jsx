
import "./checkout.css"
import Header from "../components/header"
import Footer from "../components/footer"

import Show from "../components/show";
import { useEffect } from "react";

function Checkout() {

    

    return (
        <>
            <Header />

            <div className="detail_cont">
                <div className="detail_back char">
                    <h1>Checkout</h1>
                    <button className='btn_3'>Checkout</button>
                </div>
            </div>
            <div className="cart_cont">
                <div className="cart_containerr">
                    <div className="cart_cont_one">

                    <div class="contact_form">
                        <h2>BILING ADDRESS</h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed odio justo, ultrices ac nisl sed, lobortis porta elit. Fusce in metus ac ex venenatis ultricies at cursus mauris.</p>
                        <form >
                            <label htmlFor="">Your name*</label>
                            <input type="text" required />
                            <label htmlFor="">Your email*</label>

                            <input type="email"  required />
                            <label htmlFor="">Address one*</label>

                            <input type="text"  required />
                            <label htmlFor="">Address two*</label>

                            <input type="text"  required />
                            <label htmlFor="">Phone number*</label>

                            <input type="number"  required />
                            <label htmlFor="">Zip code*</label>

                            <input type="number"  required />
                            <button className='btn_3'>Send Message</button>
                        </form>
                    </div>
                    </div>
                    <div className="cart_cont_two">
                        <div className="order_summaryy">
                        <h3>Your Order</h3>
                        <div className="summary_item">
                            <h4>Sub Total</h4>
                            <div className="summary_value cart_price">130 </div>
                        </div>
                        
                        <hr />
                        
                        <div className="summary_item">
                            <h4>Gst</h4>
                            <div className="summary_value cart_gst">2 </div>
                        </div>
                        <div className="summary_item">
                            <h4>Shipping Cost</h4>
                            <div className="summary_value"> 0 </div>
                        </div>
                        <hr />
                        <div className="summary_total">
                            <h5>Grand Total</h5>
                            <div className="summary_value cart_total"> 388 </div>
                        </div>
                        <hr />
                        <div className="shopping_box">
                            <a href="" className="btn_checkout">Checkout</a>
                        </div>

                    </div></div>
                </div>
            </div>
            <Show />
            <Footer />
        </>
    )
}
export default Checkout;