import React from 'react'
import Header from '../components/header';
import Footer from '../components/footer';
import Show from '../components/show';
import "./contact.css"

const Contact = () => {
    return (
        <>

            <Header />

            <div className="detail_cont">
                <div className="detail_back char">
                    <h1>Contact</h1>
                    <button className='btn_3'>Contact</button>
                </div>
            </div>
            <div className="contact_container">
                <div className="contact_cont">

                    <div class="contact_formm">
                        <h2>GET IN TOUCH</h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed odio justo, ultrices ac nisl sed, lobortis porta elit. Fusce in metus ac ex venenatis ultricies at cursus mauris.</p>
                        <form >
                            <input type="text" placeholder="Your Name" required />
                            <input type="email" placeholder="Your Email" required />
                            <input type="text" placeholder="Subject" required />
                            <textarea placeholder='Your Message' required></textarea>

                            <button className='btn_3'>Send Message</button>
                        </form>
                    </div>


                    <div class="contact_add">
                        
                            <h2>CONTACT INFO</h2>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent urna diam, maximus ut ullamcorper quis, placerat id eros. Duis semper justo sed condimentum rutrum. Nunc tristique purus turpis. Maecenas vulputate. </p>
                            <ul>
                                <li>
                                    <p><i class="fas fa-map-marker-alt"></i>Address: Jwala Nagar Shahdara</p>
                                </li>
                                <li>
                                    <p><i class="fas fa-phone-square"></i>Phone: <a href="tel:+91 8448260587">+91 8448260587</a></p>
                                </li>
                                <li>
                                    <p><i class="fas fa-envelope"></i>Email: <a href="mailto:yashikajaiswal30@gmail.com">yashikajaiswal30@gmail.com</a></p>
                                </li>
                            </ul>
                        
                    </div>

                </div>
            </div>
            <Show />
            <Footer />

        </>
    )
}

export default Contact;