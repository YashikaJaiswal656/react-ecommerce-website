import "./cart.css"
import Header from "../components/header"
import Footer from "../components/footer"

import Show from "../components/show";
import { useEffect } from "react";
import { Link } from "react-router-dom";


function Cart() {

    useEffect(() => {
        let amt = document.querySelector(".amt_price").innerHTML;
        let no = document.querySelector(".quantity_input");
        no.addEventListener('click', () => {
            let pr = document.querySelector(".quantity_input").value;
            let pic = amt * pr;
            let update = document.querySelector(".update_pr").innerHTML = pic;
        })
 
    })
   let update=()=>{
        let cart_sub=document.querySelector(".update_pr").innerHTML;
        document.querySelector(".cart_price").innerHTML=cart_sub;
        let gst=cart_sub*10/100;
        document.querySelector(".cart_gst").innerHTML=gst;
        let grand_price=parseInt(cart_sub)+parseInt(gst);
        document.querySelector(".cart_total").innerHTML=grand_price
        }
    return (
        <>
            <Header />

            <div className="detail_cont">
                <div className="detail_back char">
                    <h1>Cart</h1>
                    <button className='btn_3'>Cart</button>
                </div>
            </div>
            <div className="cart_cont">
                <div className="cart_container">
                    <table className="cart_table">
                        <thead className="thead">
                            <tr>
                                <th>Image</th>
                                <th>Product Name</th>
                                <th>Price</th>
                                <th>Quantity</th>
                                <th>Total</th>
                                <th>Remove</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <img src="https://themewagon.github.io/freshshop/images/big-img-03.jpg" alt="Product" className="cart_img" />
                                </td>
                                <td>Fresh Organic Apples</td>
                                <td className="amt_price">120</td>
                                <td><input type="number" minvalue={"1"} className="quantity_input " placeholder="1" /></td>
                                <td className="update_pr">120</td>
                                <td><i className="fas fa-times remove_icon"></i></td>
                            </tr>
                            
                            
                        </tbody>
                    </table>
                    <button className="but" onClick={update}>Update Cart</button>
                    <div className="order_summary">
                        <h3>Order Summary</h3>
                        <div className="summary_item">
                            <h4>Sub Total</h4>
                            <div className="summary_value cart_price">130 </div>
                        </div>
                        
                        <hr />
                        
                        <div className="summary_item">
                            <h4>Gst</h4>
                            <div className="summary_value cart_gst">2 </div>
                        </div>
                        <div className="summary_item">
                            <h4>Shipping Cost</h4>
                            <div className="summary_value"> 0 </div>
                        </div>
                        <hr />
                        <div className="summary_total">
                            <h5>Grand Total</h5>
                            <div className="summary_value cart_total"> 388 </div>
                        </div>
                        <hr />
                        <div className="shopping_box">
                            <Link to="/checkout">
                            <a href="" className="btn_checkout">Checkout</a>
                            </Link>
                            
                        </div>

                    </div>



                </div>
            </div>
            <Show />
            <Footer />
        </>
    )
}
export default Cart