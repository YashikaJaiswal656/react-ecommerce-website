let data=[
    {
        id:1,
        img:"https://themewagon.github.io/freshshop/images/img-pro-02.jpg"
        ,
        slug:"fruits",
        price:900

    },
    {
        id:2,
        img:"https://themewagon.github.io/freshshop/images/img-pro-03.jpg"
        ,
        slug:"fruits",
        price:500
    },
    {
        id:3,
        img:"https://themewagon.github.io/freshshop/images/categories_img_03.jpg",
        slug:"fruits",
        price:7000
        
    },
    {
        id:4,
        img:"https://themewagon.github.io/freshshop/images/categories_img_02.jpg"
        ,
        slug:"fruits",
        price:10000
        
    },
    
    {
        id:5,
        img:"https://themewagon.github.io/freshshop/images/categories_img_01.jpg"
        ,
        slug:"fruits",
        price:2300
        
    } ,
    {
        id:6
        ,
        slug:"fruits",
        price:690,
        
        img:"https://themewagon.github.io/freshshop/images/instagram-img-06.jpg"
    }
,
    {
        id:7
        ,
        slug:"fruits",
        price:567,
        
        img:"https://themewagon.github.io/freshshop/images/instagram-img-05.jpg"
    }
    ,
    {
        id:8
        ,
        slug:"fruits",
        price:564,
        
        img:"https://themewagon.github.io/freshshop/images/instagram-img-04.jpg"
    }
    ,
    {
        id:9
        ,
        slug:"fruits",
        price:609,
        
        img:"https://themewagon.github.io/freshshop/images/instagram-img-03.jpg"
    }
    ,
    {
        id:10
        ,
        slug:"fruits",
        price:1000,
        
        img:"https://themewagon.github.io/freshshop/images/instagram-img-02.jpg"
    }
    ,
    {
        id:11
        ,
        slug:"fruits",
        price:900,
        
        img:"https://themewagon.github.io/freshshop/images/instagram-img-01.jpg"
    }
    ,
    {
        id:12
        ,
        slug:"fruits",
        price:5673,
        
        img:"https://themewagon.github.io/freshshop/images/instagram-img-08.jpg"
    }
    ,
    {
        id:13
        ,
        slug:"fruits",
        price:239,
        
        img:"https://themewagon.github.io/freshshop/images/instagram-img-09.jpg"
    }
    ,
    {
        id:14
        ,
        slug:"fruits",
        price:467,
        
        img:"https://themewagon.github.io/freshshop/images/instagram-img-07.jpg"
    }
]
export default data