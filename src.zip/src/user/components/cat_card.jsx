import React, { useEffect } from 'react';
import OwlCarousel from 'react-owl-carousel';
import 'owl.carousel/dist/assets/owl.carousel.css';
import 'owl.carousel/dist/assets/owl.theme.default.css';
import data from "./data.js";

import { Link } from "react-router-dom";

function Cat_card() {
  return (
    <>
    <div className="cat_s_img item" >
      {data.map((item, index) => (
        <Link to="../about"> 
        
        <div class="products-single" key={index}>
        <div class="box-img-hover">
            <div class="type-lb">
                <p class="sale">Sale</p>
            </div>
            <img src={item.img} alt="Product Image"/>
            <div class="mask-icon">
                <a class="cart" href="#">Add to Cart</a>
                <ul>
                    <li><a href="#" title="View"><i class="fas fa-eye"></i></a></li>
                    <li><a href="#" title="Compare"><i class="fas fa-sync-alt"></i></a></li>
                    <li><a href="#" title="Add to Wishlist"><i class="far fa-heart"></i></a></li>
                </ul>
            </div>
        </div>
        <div class="why-text">
            <h4>Lorem ipsum dolor sit amet</h4>
            <h5>{item.price}</h5>
        </div>
    </div>
        
        </Link>
      ))}
      </div>
    </>
  );
}

export default Cat_card;
