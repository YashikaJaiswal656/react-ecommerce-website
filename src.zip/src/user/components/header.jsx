

import './header.css'

import { Link } from "react-router-dom";
function Header() {
    const toggleMenu = () => {
        const sideMenu = document.querySelector(".side_two");
        const menuIcon = document.querySelector(".menu-icon");

        if (sideMenu.classList.contains("showw")) {
            sideMenu.classList.remove("showw"); // Hide menu
            menuIcon.classList.remove("fa-times"); // Switch to bars
            menuIcon.classList.add("fa-bars");
        } else {
            sideMenu.classList.add("showw"); // Show menu
            menuIcon.classList.remove("fa-bars"); // Switch to cross
            menuIcon.classList.add("fa-times");
        }
    };
    return (
        <>

            <div className="nav">
                <div className="item">
                    <ul>
                        <li>
                            <a href="">
                                <i className='fa fa-user s_color'></i>
                                My Account  |</a>
                        </li>
                        
                        <li>
                            <a href="">
                                <i className='fas fa-location-arrow'></i>
                                Our location  |</a>
                        </li>
                        
                        <li>
                            <a href="">
                                <i className='fas fa-headset'></i>
                                Contact Us  |</a>
                        </li>
                    </ul>
                </div>
                <div className="register">
                    <button>Register here</button>
                </div>
            </div>
            <div className="two_nav">
            <i className="fa fa-bars menu-icon" onClick={toggleMenu}></i>

            
                <div className="logo">
                
                    <img src="https://themewagon.github.io/freshshop/images/logo.png" alt="" />
                    
                </div>
                <div className="two_item">
                    <ul>
                        <Link to="/"><li>Home</li></Link>
                        
                        <Link to="/about"><li>Shop</li></Link>
                        
                        <Link to="/developer"><li>About Us</li></Link>
                        <Link to="/Gallery"><li>Gallery</li></Link>
                        <Link to="/cart"><li>Cart</li></Link>
                        
                        <Link to="/contact"><li>Contact Us</li></Link>


                    </ul>
                </div>
            </div>
            <div className="side_two">
                <div className="side_list">
                <ul>
                        <Link to="/"><li>Home</li></Link>
                        
                        <Link to="/about"><li>Shop</li></Link>
                    <Link to="/developer"><li>About Us</li></Link>
                    
                    <Link to="/Gallery"><li>Gallery</li></Link>
                        <Link to="/cart"><li>Cart</li></Link>
                    <Link to="/contact"><li>Contact Us</li></Link>
                </ul>
                </div>
            </div>



        </>
    )
    
}

export default Header;