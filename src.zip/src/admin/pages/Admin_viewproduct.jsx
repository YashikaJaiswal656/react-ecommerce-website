import React from 'react'
import Admin_header from '../components/admin_header';
import Admin_footer from '../components/Admin_footer';
import "./Admin_viewproduct.css"
import Admin_sidebar from '../components/admin_sidebar';
import data from '../../user/components/data';
import { Link } from 'react-router-dom';


const Admin_viewproduct = () => {
  return (
    <>
      <Admin_header />

      <div className="view_cont">
        <Admin_sidebar />
        <div className="view_back">
        {data.map((item, index) => (
        
          
        
        

            <div className="view_box">
              <img src={item.img} alt="" />
              <h2>{item.slug}</h2>
              <div className="pricee"><h1><sup>₹</sup>{item.price}</h1></div>
              <p>High-resolution camera with night vision, motion detection, and cloud storage support.</p>
              <div className="button">
                <Link to="/edit-product">
                <button className="edit"><i className="fas fa-edit"></i> Edit</button>  </Link>
                <button className="delete"><i className="fas fa-trash"></i> Delete</button>
                <button className="view"><i className="fas fa-eye"></i> View</button>
              </div>
            </div>
                  ))}
                  </div>
          </div>
        
      
      <Admin_footer />

    </>
  )
}

export default Admin_viewproduct;