import React from 'react'
import "./Admin_cat.css"
import  { useEffect } from 'react';


import { Link } from "react-router-dom";
import Admin_header from '../components/admin_header';
import Admin_footer from '../components/Admin_footer';
import Admin_sidebar from '../components/admin_sidebar';
function Admin_edit() {
  useEffect(() => {
    // Initialize TinyMCE
    tinymce.init({
      selector: 'textarea',
      plugins: "lists link image table code",
      toolbar:
        "undo redo | styleselect | bold italic | alignleft aligncenter alignright | bullist numlist | link image | code",
      branding: false,
      forced_root_block: false,
    });

    
  })

  return (
    <>
      <Admin_header />
      <div className="container_admin">
        <Admin_sidebar/>
        <div className="form-container">
        <h3>Product Name</h3>
        <input type="text" placeholder="Product Name" />

        <h3>Short Description</h3>
        <input type="text" placeholder="Description" />
        
        <h3>Long Description</h3>
        <textarea  type="text" id=""></textarea>
        <h3>Add Category</h3>
        <input type="text" placeholder="Category" />
        
        <h3>Rating</h3>
        <input type="number" placeholder="Rating" />
        
        <h3>Price</h3>
        <input type="number" placeholder="Price" />
        
        <h3>Offer</h3>
        <input type="text" placeholder="Offer" />
        
        <h3>Photos</h3>
        <input type="file" placeholder="Price" />
        <h3>Photos</h3>
        <input type="file" placeholder="Price" />
        <h3>Photos</h3>
        <input type="file" placeholder="Price" />
        <h3>Photos</h3>
        <input type="file" placeholder="Price" />
        <h3>Photos</h3>
        <input type="file" placeholder="Price" />
        <h3>Photos</h3>
        <input type="file" placeholder="Price" />
        
        <button>Add Product</button>
      </div>
      </div>
      

      <Admin_footer />
    </>
  )
}
export default Admin_edit