import React from 'react'
import "./Admin_cat.css"

import { Link } from "react-router-dom";
import Admin_header from '../components/admin_header';
import Admin_footer from '../components/Admin_footer';
import Admin_sidebar from '../components/admin_sidebar';
function Insert() {
  return (
    <>
      <Admin_header />
      <div className="container_admin">
        <Admin_sidebar/>
        <div className="form-container">
        <h3>Create Category</h3>
        <input type="text" placeholder="Category Name" />

        <h3>Create Slug</h3>
        <input type="text" placeholder="Slug Name" />
        <button>Add Category</button>
      </div>
      </div>
      

      <Admin_footer />
    </>
  )
}
export default Insert