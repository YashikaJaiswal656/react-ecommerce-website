import React from 'react'
import "./Admin_header.css"

import { Link } from "react-router-dom";
const Admin_header = () => {

    return (

        <>


            <div className="navbar">
                <h1>Business Admin</h1>
                <ul>
                    <li>LogOut</li>
                </ul>
            </div>

        </>
    )
}

export default Admin_header