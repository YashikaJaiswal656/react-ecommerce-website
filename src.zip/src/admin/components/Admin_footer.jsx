import React from 'react'
import "./admin_footer.css"

const Admin_footer = () => {
  return (
    <>
    <div className="bottom">
      <p>© 2024 ThewayShop | Developed by <a href="">YASHIKA JAISWAL</a></p>
    </div>
    </>
  )
}

export default Admin_footer