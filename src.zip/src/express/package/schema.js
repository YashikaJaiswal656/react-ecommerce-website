const mongoose=require("mongoose")
const userSchema=new mongoose.Schema({
    name:String,
    description:String,
    details:String,
    cat:String,
    price:Number,
    
    rating:String
})
module.exports=mongoose.model("user",userSchema);