const schema=require("./schema");
const express=require("express")
const cors=require("cors")
const mongoose=require("mongoose")
const PORT=3000
const app=express();
app.use(cors());
app.use(express.json());
mongoose.connect("mongodb://localhost:27017/local", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => console.log("✅ MongoDB Connected"))
  .catch((err) => console.error("❌ MongoDB Error:", err));

app.get("/submit",async(req,res)=>{
    try{
const users=await schema.find()
res.json(users)
    }
    catch(error){
console.log("error",error);

    }
})
app.post("/submit",async(req,res)=>{
    try{
const {name,description,details,cat,rating,price}=req.body
const newUser=new schema({name,description,details,cat,price,rating})
await newUser.save()
res.status(201).json(newUser)

    }
    catch (error) {
        res.status(500).json({ message: "Server Error", error });
      }
})








  app.listen(PORT,()=>{
    console.log("sucess")
  })
